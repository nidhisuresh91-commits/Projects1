import torch
import zipfile
from diffusers import StableDiffusionPipeline

model_id = "stable-diffusion-v1-5/stable-diffusion-v1-5"
pipe = StableDiffusionPipeline.from_pretrained(model_id,torch_dtype=torch.float16)

pipe = pipe.to("cuda")
prompt = "4k magical fantasy forest with tiny fairies and glowing mushrooms in the night with fireflies "

image = pipe(prompt).images[0]
image.save("task_output_image.png")
